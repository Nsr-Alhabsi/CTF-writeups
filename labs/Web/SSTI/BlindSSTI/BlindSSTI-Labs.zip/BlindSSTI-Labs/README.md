# Blind SSTI — Self-Hosted Labs

Local, offline practice for **blind** server-side template injection — the
case PortSwigger locks behind Burp Pro's Collaborator. No Burp, no paid tools,
no internet needed. Everything runs on `127.0.0.1` and you catch callbacks with
your own listener. This is also the *finals-authentic* way to practise: pure
terminal, curl-driven, no vendor tooling.

## ⚠️ Safety

These servers are **vulnerable by design** and give remote code execution.
Run them **only inside your isolated VM** (host-only / NAT). Never expose them
to a real network or bind them to `0.0.0.0`.

## Setup (once)

```bash
pip install flask          # the only dependency
```

## The labs

| Lab | Theme | What it teaches |
| --- | --- | --- |
| **Lab01-TimeAndOOB** | Feedback service | Blind detection via **timing**, then **OOB exfil** of the flag |
| **Lab02-FilteredBlind** | Bio moderation | A `{{ }}` **WAF bypass** with statement tags, **pure-OOB** (no timing, no errors) |

Each lab folder holds:
- `README.md` — the scenario + how to run. **Start here. No spoilers.**
- `app.py` — the vulnerable server (listens on `127.0.0.1:8000`).
- `listener.py` — your OOB callback catcher (your free Collaborator).
- `INDEX.md` — the **full walkthrough**. Open it **only after** you've solved
  it or genuinely exhausted yourself. This is the "Solution" button.

## The discipline (don't break it)

1. Read only the lab's `README.md`.
2. Start a 90-minute timer. Solo. **No AI.**
3. Attack with `curl` and your `listener.py`.
4. Stuck 20+ min on one idea? Change the idea, not the timer.
5. Timer done → write your own cheat sheet from memory → *then* open `INDEX.md`
   and compare it to what you did.

The payload you reconstruct from the mechanism is the one you'll still have on
Dec 1 with no internet and no me. The one you copy from `INDEX.md` is not.
